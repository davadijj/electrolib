/** @file electrotestgtk.c */

#include <gtk/gtk.h>
#include <stdlib.h>  

typedef int bool;
#define true 1
#define false 0

int e_resistance(float orig_resistance, float *res_array );
float calc_power_r(float volt, float resistance);
float calc_power_i(float volt, float current);
float calc_resistance(int count, char conn, float *array);

/**
 * @brief convinience stuct representing the application, for passing the application data to callback functions
 */
struct electro_app
{
  GtkWidget *window;
  GtkWidget *grid;

  // Buttons
  GtkWidget *calc_button;
  GtkWidget *quit_button;

  // input fields
  GtkWidget *current_resistance_input;
  GtkWidget *voltage_input;
  GtkEntryBuffer *current_resistance_buffer;
  GtkEntryBuffer *voltage_buffer;

  // Text views
  GtkWidget *voltage_text;
  GtkTextBuffer *voltage_text_buffer;
  GtkWidget *total_resistance_text;
  GtkTextBuffer *total_resistance_text_buffer;
  GtkWidget *e12_resistors_text;
  GtkTextBuffer *e12_resistors_text_buffer;
  GtkWidget *power_text;
  GtkTextBuffer *power_text_buffer;

  // Calculate power using current or resistans
  GtkWidget *radio_res;
  GtkWidget *radio_current;
  bool use_current;

  // Calculate power using parrallel or serial coupled resistors
  GtkWidget *radio_serial;
  GtkWidget *radio_parrallel;
  bool serial_r;

} info;


/**
 * @brief callback function for calc_button
 * @param GtkWidget *widget,
 * @param gpointer data
 */
void calculate (GtkWidget *widget,
             gpointer   data)
{
  struct electro_app *e_info = data;
  if(e_info->use_current)
  {
    gchar *power_string; 
    float current = strtof(gtk_entry_buffer_get_text(e_info->current_resistance_buffer), NULL);
    float voltage = strtof(gtk_entry_buffer_get_text(e_info->voltage_buffer), NULL);
    power_string = g_strdup_printf ("Power:\n%f W\0", calc_power_i(voltage, current));
    gtk_text_buffer_set_text(e_info->power_text_buffer, power_string, -1);    
    gtk_text_buffer_set_text(e_info->e12_resistors_text_buffer, "\0", -1);
    gtk_text_buffer_set_text(e_info->total_resistance_text_buffer, "\0", -1);
    g_free(power_string);
  }
  else
  {
    gchar *resistance_string = gtk_entry_buffer_get_text(e_info->current_resistance_buffer);
    gint string_size = gtk_entry_buffer_get_length(e_info->current_resistance_buffer);
    GArray *resistors = g_array_new (FALSE, FALSE, sizeof(float));
    gint b = 0, num_resistors = 0;
    char* pend;
    while(b < string_size)
    {
      char *beg = &(resistance_string[b]);
      float r = strtof(beg, &pend);
      g_array_append_val(resistors, r);
      ++num_resistors; 
      while(b < string_size && resistance_string[b] != ' ') ++b;
      ++b;
    }
    char type = e_info->serial_r ? 'S' : 'P';
    float resistance = calc_resistance(num_resistors, type, resistors->data);
    resistance_string = g_strdup_printf ("Total resistance:\n%f Ohm\0", resistance);
    gtk_text_buffer_set_text(e_info->total_resistance_text_buffer, resistance_string, -1);
    g_free(resistance_string);

    gchar *power_string; 
    float voltage = strtof(gtk_entry_buffer_get_text(e_info->voltage_buffer), NULL);
    power_string = g_strdup_printf ("Power:\n%f W\0", calc_power_r(voltage, resistance));
    gtk_text_buffer_set_text(e_info->power_text_buffer, power_string, -1);
    g_free(power_string); 

    float e12_resistors[3];
    int num_e12_resistors;
    num_e12_resistors = e_resistance(resistance, &e12_resistors);
    GString *string = g_string_new (NULL);
    g_string_append_printf (string, "E12 resistors:");
    for(int i = 0; i < num_e12_resistors; ++i)
    {
      g_string_append_printf (string, "\n%f", e12_resistors[i]);
    }
    gchar *e12_resistors_string = g_string_free(string, FALSE); 
    gtk_text_buffer_set_text(e_info->e12_resistors_text_buffer, e12_resistors_string, -1);
    g_free(e12_resistors_string);
  } 
}

/**
 * @brief callback function for info->radio_serial
 * @param GtkWidget *widget,
 * @param gpointer data
 */
void
s_toggled (GtkWidget *widget,
             gpointer   data)
{
  struct electro_app *e_info = data;
  e_info->serial_r = true;
}

/**
 * @brief callback function for info->radio_parrallel
 * @param GtkWidget *widget,
 * @param gpointer data
 */
void
p_toggled (GtkWidget *widget,
             gpointer   data)
{
  struct electro_app *e_info = data;
  e_info->serial_r = false;
}

/**
 * @brief callback function for info->radio_res
 * @param GtkWidget *widget,
 * @param gpointer data
 */
void
resistance_toggled (GtkWidget *widget,
             gpointer   data)
{
  struct electro_app *e_info = data;
  e_info->use_current = false;
  gtk_widget_show(e_info->radio_serial);
  gtk_widget_show(e_info->radio_parrallel);
}

/**
 * @brief callback function for info->radio_current
 * @param GtkWidget *widget,
 * @param gpointer data
 */
void
current_toggled (GtkWidget *widget,
             gpointer   data)
{
  struct electro_app *e_info = data;
  e_info->use_current = true;
  gtk_widget_hide(e_info->radio_serial);
  gtk_widget_hide(e_info->radio_parrallel);
}

/**
 * @brief Configures the application
 * @param GtkApplication *app,
 * @param gpointer user_data
 */
void
activate (GtkApplication *app,
          gpointer        user_data)
{
  info.current_resistance_buffer = gtk_entry_buffer_new(NULL, -1);
  info.voltage_buffer = gtk_entry_buffer_new(NULL, -1);

  /* create a new window, and set its title */
  info.window = gtk_application_window_new (app);
  gtk_window_set_title (GTK_WINDOW (info.window), "Window");
  gtk_container_set_border_width (GTK_CONTAINER (info.window), 10);

  /* Here we construct the container that is going pack our buttons */
  info.grid = gtk_grid_new ();

  /* Pack the container in the window */
  gtk_container_add (GTK_CONTAINER (info.window), info.grid);

  // Radio buttons
  info.radio_res = gtk_radio_button_new_with_label (NULL, " resistance ");
  info.radio_current = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (info.radio_res), " current ");
  gtk_grid_attach (GTK_GRID (info.grid), info.radio_current, 2, 0, 1, 1);  
  g_signal_connect (info.radio_current, "toggled", G_CALLBACK (current_toggled), &info);
  gtk_grid_attach (GTK_GRID (info.grid), info.radio_res, 3, 0, 1, 1);
  g_signal_connect (info.radio_res, "toggled", G_CALLBACK (resistance_toggled), &info);

  info.radio_parrallel  = gtk_radio_button_new_with_label (NULL, " parallel "); 
  info.radio_serial = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (info.radio_parrallel), " serial ");
  gtk_grid_attach (GTK_GRID (info.grid), info.radio_parrallel, 4, 0, 1, 1);
  g_signal_connect (info.radio_parrallel, "toggled", G_CALLBACK (p_toggled), &info);
  gtk_grid_attach (GTK_GRID (info.grid), info.radio_serial, 5, 0, 1, 1);  
  g_signal_connect (info.radio_serial, "toggled", G_CALLBACK (s_toggled), &info);


  // Inputs
  info.current_resistance_input = gtk_entry_new_with_buffer(info.current_resistance_buffer);
  gtk_grid_attach (GTK_GRID (info.grid), info.current_resistance_input, 0, 0, 2, 1);

  info.voltage_input = gtk_entry_new_with_buffer(info.voltage_buffer);
  gtk_grid_attach (GTK_GRID (info.grid), info.voltage_input, 0, 1, 2, 1);


  // Text fields
  gtk_text_view_set_editable((info.voltage_text = gtk_text_view_new ()), false);
  info.voltage_text_buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (info.voltage_text));
  gtk_text_buffer_set_text (info.voltage_text_buffer, "Voltage ", -1); 
  gtk_grid_attach (GTK_GRID (info.grid), info.voltage_text, 2, 1, 1, 1);  

  gtk_text_view_set_editable((info.total_resistance_text = gtk_text_view_new ()), false);
  info.total_resistance_text_buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (info.total_resistance_text));
  gtk_text_buffer_set_text (info.total_resistance_text_buffer, "Total resistance: ", -1); 
  gtk_grid_attach (GTK_GRID (info.grid), info.total_resistance_text, 4, 1, 1, 2);  

  gtk_text_view_set_editable((info.e12_resistors_text = gtk_text_view_new ()), false);
  info.e12_resistors_text_buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (info.e12_resistors_text));
  gtk_text_buffer_set_text (info.e12_resistors_text_buffer, "E12 resistors: ", -1); 
  gtk_grid_attach (GTK_GRID (info.grid), info.e12_resistors_text, 5, 1, 1, 2);  

  gtk_text_view_set_editable((info.power_text = gtk_text_view_new ()), false);
  info.power_text_buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (info.power_text));
  gtk_text_buffer_set_text (info.power_text_buffer, "Power: ", -1); 
  gtk_grid_attach (GTK_GRID (info.grid), info.power_text, 3, 1, 1, 2);

  // Buttons
  info.calc_button = gtk_button_new_with_label ("Calc");
  g_signal_connect (info.calc_button, "clicked", G_CALLBACK (calculate), &info);
  gtk_grid_attach (GTK_GRID (info.grid), info.calc_button, 0, 2, 1, 1);

  info.quit_button = gtk_button_new_with_label ("Quit");
  g_signal_connect_swapped (info.quit_button, "clicked", G_CALLBACK (gtk_widget_destroy), info.window);
  gtk_grid_attach (GTK_GRID (info.grid), info.quit_button, 1, 2, 1, 1);

  gtk_widget_show_all (info.window);

}

int
main (int    argc,
      char **argv)
{
  GtkApplication *app;
  int status;

  app = gtk_application_new ("org.gtk.example", G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
  status = g_application_run (G_APPLICATION (app), argc, argv);
  g_object_unref (app);

  return status;
}
