/*
	testprogram  som kan användas
	för test av biblioteken
*/

#include <stdio.h>
#include <stdlib.h>


#include "libresistance/resistance.h"
#include "libpower/power.h"
#include "libcomponent/component.h"


/**
 * @brief A test program for the libraries that we (David, Christer, Jonathan) created.
 * I actually dont remember who wrote the test so I will credit all of us for the sake of simplicity.
 * It takes no parameters, instead it features a prompt that requests input from the user.
 * @return Always 0
 * @author David, Christer, Jonathan
 * @date 10-23-2018
 */
int main()
{

	float volt = 0.0;
	int numberOfcomponents = 0;
	char conn;

	printf("Ange spänningskälla i V: ");
	scanf("%f", &volt);
	getchar();

	printf("Ange koppling[S | P]: ");
	scanf("%c",&conn);
	getchar();

	printf("Antal komponenter: ");
	scanf("%d",&numberOfcomponents);
	getchar();

	float *original_resistors = malloc(sizeof(float) * numberOfcomponents);
	if (original_resistors == 0) return 1;

	for (int i= 0; i < numberOfcomponents; i++ )
	{
		printf("Komponent  %d i ohm: ", i+1);
		scanf("%f", &original_resistors[i]);
		getchar();
	}

	float actual_resistance = calc_resistance(numberOfcomponents,
			conn, original_resistors);
	if (actual_resistance < 0) return 1;

	float power = calc_power_r(volt, actual_resistance);

	printf("Ersättningsresistans: %.0f ohm\n", actual_resistance);
	printf("Effekt: %.2f W\n", power);

	float *e12_resistors = malloc(sizeof(float) * 3);
	if (e12_resistors == 0) return 1;

	int num_e12 = e_resistance(actual_resistance, e12_resistors);

	printf("Ersättningsresistanser i E12-serien kopplade i serie: ");
	float e12_resistance = 0.0;

	for (int i = 0; i < num_e12; i++)
	{
		if(i == (num_e12 - 1))
		{
			printf("%.0f\n", e12_resistors[i]);
		}
		else
		{
			printf("%.0f, ", e12_resistors[i]);

		}
		e12_resistance += e12_resistors[i];
	}

	free(original_resistors);
	free(e12_resistors);

	return 0;
}
