/**
 * Testprogram for resistance library
 * David Jonsson 10-02-2017
 */
#include "./libresistance/resistance.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if(argc < 3)
    {
        fprintf(stderr, "Usage: %s [S/P] [resistor1, resistor2, ...]\n", argv[0]);
        return 0;
    }

    float *res;
    res = (float *) malloc(sizeof(float) * (argc - 2)); 
    
    for(int i = 0; i < argc - 2; ++i)
    {
        res[i] = (float) atof(argv[i + 2]);
    }
    printf("Resulting resistance: %f\n", calc_resistance(argc - 2, (char) *argv[1], res));
    free(res);
    return 0;
}

