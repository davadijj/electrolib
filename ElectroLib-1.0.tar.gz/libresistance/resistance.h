#ifndef RESISTANCE_LIBRARY_H
#define RESISTANCE_LIBRARY_H

/**
 * @brief Calculates resistance for a group of either parallelly or serially connected resistors.
 * @param count resistor count
 * @param conn connection type, 'S' for serial, 'P' for parallel
 * @param array array of resistances
 * @return Error returns -1.0
 * @author David Jonsson
 * @date 10-13-2017
 */
float calc_resistance(int count, char conn, float *array);

#endif
