#include <stdlib.h>
#include "resistance.h"

float calc_resistance(int count, char conn, float *array)
{
    float res = 0;
    if(array == NULL) return -1;

    // Parralell coupling is calculated like this:
    // res_par = 1 / ( 1 / res1 + 1 - res2 + ...)
    if(conn == 'P')
    {
        for(int i = 0; i < count; ++i)
        {
            if(array[i] == 0)
            {
                return 0;
            }
            res += 1 / array[i];
        }
        return 1 / res;
    }

    // Parralell coupling is calculated like this:
    // res_ser = res1 + res2 + ...
    else if(conn == 'S')
    {
        for(int i = 0; i < count; ++i)
        {
            res += array[i];
        }
        return res;
    }
    else return -1;
}
