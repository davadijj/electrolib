//#include <stdio.h>
#include <math.h>
#include "component.h"

#define E12_DECADES 4

float e12[] =
{
    1.0f,
    1.2f,
    1.5f,
    1.8f,
    2.2f,
    2.7f,
    3.3f,
    3.9f,
    4.7f,
    5.6f,
    6.8f,
    8.2f
};


/**
 *  int count = e_resistance(float orig_resistance, float *res_array );
 *
 *  En funktion som beräknar vilka tre seriekopplade resistorer i E12-serien
 *  som närmast ersätter den resistans som skickas med.

 *  - orig_resistance är ersättningsresistansen.
 *  - *res_array är en pekare till en array med 3 resistorer som ska fyllas med
 *    värden ur E12-serien.
 *  - count är hur många resistorer ur E12-serien som behövdes för att ersätta
 *  - orig_resistance. Om inte alla 3 komponenterna behövs ska de som inte
 *    används fyllas med värdet 0. count kan anta värde mellan 0 och 3.
 */

int e_resistance(float orig_resistance, float *res_array)
{
    float remainder = orig_resistance;
    int resistances_used = 0;

    for (int i = 0; i<3; ++i)
    {
        // printf("remainder: %.1f\n", remainder);
        res_array[i] = 0.0f;

        // don't break even if done, to ensure zeroing of the whole array
        if (!remainder) continue;

        for (int p = pow(10, E12_DECADES); p>0; p/=10)
        {
            if (res_array[i] > 0) break;

            // printf("new decade: %d\n", p);

            for (int e12_idx = 11; e12_idx>=0; --e12_idx)
            {
                float res = e12[e12_idx] * p;

                if ((remainder - res) >= 0)
                {
                    // printf("res_array[%d] = %.1f fits\n", i, res);
                    remainder -= res;
                    res_array[i] = res;
                    ++resistances_used;
                    break;
                }
            }
        }
    }

    /* float total = orig_resistance - remainder;
    float percentage = (total / orig_resistance) * 100;

    printf("%.1f%% match: %.1f / %.1f (remainder %.1f)\n",
            percentage, total, orig_resistance, remainder); */

    return resistances_used;
}
