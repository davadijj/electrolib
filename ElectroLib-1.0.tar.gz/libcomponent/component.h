#ifndef __LINUM150_COMPONENT__
#define __LINUM150_COMPONENT__

int e_resistance(float orig_resistance, float *res_array );

#endif

