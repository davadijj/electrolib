#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "component.h"

void unittest()
{
    float *res = malloc(sizeof(float) * 3);

    // 1398 Ohm --> 3: 1200 + 180 + 18
    assert(e_resistance(1398.0f, res) == 3);
    assert(res[0] == 1200.0f);
    assert(res[1] == 180.0f);
    assert(res[2] == 18.0f);

    // 0 Ohm --> nothing
    assert(e_resistance(0.0f, res) == 0);

    // -1 Ohm --> invalid, so nothing
    assert(e_resistance(-1.0f, res) == 0);

    // 1 Ohm --> 1: 1
    assert(e_resistance(1.0f, res) == 1);
    assert(res[0] == 1.0f);

    // 314 Ohm --> 3: 270 + 39 + 4.7
    assert(e_resistance(314.0f, res) == 3);
    assert(res[0] == 270.0f);
    assert(res[1] == 39.0f);
    assert(res[2] == 4.7f);

    // 99999 Ohm --> 3: 82000 + 15000 + 2700
    assert(e_resistance(99999.0f, res) == 3);
    assert(res[0] == 82000.0f);
    assert(res[1] == 15000.0f);
    assert(res[2] == 2700.0f);

    // 99.9 Ohm --> 3: 82 + 15 + 2.7
    assert(e_resistance(99.9f, res) == 3);
    assert(res[0] == 82.0f);
    assert(res[1] == 15.0f);
    assert(res[2] == 2.7f);

    // 21 Ohm --> 2: 18 + 2.7
    assert(e_resistance(21.0f, res) == 2);
    assert(res[0] == 18.0f);
    assert(res[1] == 2.7f);
}

int main(int argc, char **argv)
{
    unittest();

    if (argc != 2)
    {
        printf("Usage: %s [resistance in ohm]\n", argv[0]);
        return 0;
    }

    float *resistors = malloc(sizeof(float) * 3);
    if (!resistors) return 1;  // implicit boolean conversion

    int resistors_used = e_resistance(atof(argv[1]), resistors);

    printf("resistors used: %d\n", resistors_used);

    for (int i = 0; i<resistors_used; ++i)
    {
        printf("resistor %d: %.1f\n", i, resistors[i]);
    }

    free(resistors);
    return 0;
}
