/**
 * @author Christer Vadman
 * @file power.h
 * @brief Calculates the power of a circuit 
 */

#ifndef POWER_H 
#define POWER_H

/**
 * @name calc_power_r
 * @param float volt
 * $param float resistance
 * @return float power
 */
float calc_power_r(float volt, float resistance);

/**
 * @name calc_power_i
 * @param float volt
 * @param float current
 * @return float power
 */
float calc_power_i(float volt, float current);
#endif
